package lx;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;

public class System_Method  {

	
	
	       
		public static void selectAll(){
	
			Con_SQL con=new Con_SQL();
			con.Con_SQL();
			Statement 	stmt=null;
			ResultSet rs=null;
				try {
						stmt = con.connect.createStatement();
						rs=stmt.executeQuery("select * from user ");
					while(rs.next()) {
					System.out.print(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3)+"\n");} 
					
					
//					if(rs!=null)rs.close();
//						if(rs!=null)stmt.close();
//							if(rs!=null)con.connect.close();
					
				}catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
				
				finally {
					try {
					if(rs!=null)rs.close();}
					catch(Exception e2) {
						e2.printStackTrace(); 
					}
					try {if(rs!=null)stmt.close();
						}
					catch(Exception e3) {
						e3.printStackTrace(); 
					}
					try {if(rs!=null)con.connect.close();
						}
					catch(Exception e4) {
						e4.printStackTrace(); 
					}
				}
			
				}	
				
		public static boolean selectByusername(String username){
			
			Con_SQL con1=new Con_SQL();
			con1.Con_SQL();
			Statement 	stmt1=null;
			ResultSet rs1=null;
				try {
						stmt1 = con1.connect.createStatement();
						String sql="select * from user where username='"+username+"'";
						rs1=stmt1.executeQuery(sql);
						if(rs1.next()) { System.out.print(rs1.getInt(1)+"  "+rs1.getString(2)+"  "+rs1.getString(3)+"\n"); return true;}
						else { 
							
						return false;}
					
					
//					if(rs!=null)rs.close();
//						if(rs!=null)stmt.close();
//							if(rs!=null)con.connect.close();
					
				}catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
				
				finally {
					try {
//						System.out.print(rs1.next());
					if(rs1!=null)rs1.close();}
					catch(Exception e2) {
						e2.printStackTrace(); 
					}
					try {if(stmt1!=null)stmt1.close();
						}
					catch(Exception e3) {
						e3.printStackTrace(); 
					}
					try {if(con1!=null)con1.connect.close();
						}
					catch(Exception e4) {
						e4.printStackTrace(); 
					}
					}
					return false;	}
			
		public static boolean selectByid(int id){
			
			Con_SQL con2=new Con_SQL();
			con2.Con_SQL();
			PreparedStatement 	prestm=null;
			ResultSet rs2=null;
				try {	String sql1="select * from user where id = ?" ;
						prestm = con2.connect.prepareStatement(sql1);
						prestm.setInt(1, id);
						rs2=prestm.executeQuery();
						if(rs2.next()) { System.out.print(rs2.getInt(1)+"  "+rs2.getString(2)+"  "+rs2.getString(3)+"\n"); return true;}
						else { 
							
						return false;}
					
					
//					if(rs!=null)rs.close();
//						if(rs!=null)stmt.close();
//							if(rs!=null)con.connect.close();
					
				}catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
				
				finally {
					try {
//						System.out.print(rs1.next());
					if(rs2!=null)rs2.close();}
					catch(Exception e2) {
						e2.printStackTrace(); 
					}
					try {if(prestm!=null)prestm.close();
						}
					catch(Exception e3) {
						e3.printStackTrace(); 
					}
					try {if(con2!=null)con2.connect.close();
						}
					catch(Exception e4) {
						e4.printStackTrace(); 
					}
					}
					return false;	}
		
		//�ڼ�ҳint pageNumber�ӵ�0ҳ��ʼ,ÿҳ��������int pageCount  (ҳ��-1,ÿҳ����)
         public static boolean selectBypage(int pageNumber,int pageCount){
			Con_SQL con3=new Con_SQL();
			con3.Con_SQL();
			PreparedStatement 	prestm1=null;
			ResultSet rs3=null;
				try {	String sql2="select * from user limit ?,? " ;
						prestm1 = con3.connect.prepareStatement(sql2);
						prestm1.setInt(1, (pageNumber-1)*pageCount);
						prestm1.setInt(2, pageCount);
						rs3=prestm1.executeQuery();
						while(rs3.next()) {
							System.out.print(rs3.getInt(1)+"  "+rs3.getString(2)+"  "+rs3.getString(3)+"\n");} 
							return true;
					
//					if(rs!=null)rs.close();
//						if(rs!=null)stmt.close();
//							if(rs!=null)con.connect.close();
					
				}catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
				
				finally {
					try {
//						System.out.print(rs1.next());
					if(rs3!=null)rs3.close();}
					catch(Exception e2) {
						e2.printStackTrace(); 
					}
					try {if(prestm1!=null)prestm1.close();
						}
					catch(Exception e3) {
						e3.printStackTrace(); 
					}
					try {if(con3!=null)con3.connect.close();
						}
					catch(Exception e4) {
						e4.printStackTrace(); 
					}
					}
					return false;	}
	
        public static void insert(String username,String password){
        		
    			Con_SQL con=new Con_SQL();
    			con.Con_SQL();
    			PreparedStatement 	stmt=null;
    			ResultSet rs=null;
    				try {     String sql="insert into user (username,password) values(?,?)";
    						stmt = con.connect.prepareStatement(sql);
    						stmt.setString(1, username);
    						stmt.setString(2, password);
    					int	result=stmt.executeUpdate();
    					if(result>0) System.out.print("����ɹ�");else System.out.print("����ʧ��");
//    					if(rs!=null)rs.close();
//    						if(rs!=null)stmt.close();
//    							if(rs!=null)con.connect.close();
    					
    				}catch (SQLException e1) {
    					// TODO �Զ����ɵ� catch ��
    					e1.printStackTrace();
    				}
    				
    				
    				finally {
    					try {
    					if(rs!=null)rs.close();}
    					catch(Exception e2) {
    						e2.printStackTrace(); 
    					}
    					try {if(rs!=null)stmt.close();
    						}
    					catch(Exception e3) {
    						e3.printStackTrace(); 
    					}
    					try {if(rs!=null)con.connect.close();
    						}
    					catch(Exception e4) {
    						e4.printStackTrace(); 
    					}
    				}
    			
    				}	
		
        public static void deleteByid(int id){
    		
			Con_SQL con=new Con_SQL();
			con.Con_SQL();
			PreparedStatement 	stmt=null;
			ResultSet rs=null;
				try {     String sql="delete from user where id = ? ";
						stmt = con.connect.prepareStatement(sql);
						stmt.setInt(1, id);
					int	result=stmt.executeUpdate();
					if(result>0) System.out.print("ɾ���ɹ�");else System.out.print("ɾ��ʧ��");
//					if(rs!=null)rs.close();
//						if(rs!=null)stmt.close();
//							if(rs!=null)con.connect.close();
					
				}catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
				
				finally {
					try {
					if(rs!=null)rs.close();}
					catch(Exception e2) {
						e2.printStackTrace(); 
					}
					try {if(rs!=null)stmt.close();
						}
					catch(Exception e3) {
						e3.printStackTrace(); 
					}
					try {if(rs!=null)con.connect.close();
						}
					catch(Exception e4) {
						e4.printStackTrace(); 
					}
				}
			
				}	
        
        public static void updatePassword(int id,String newpassword){
    		
			Con_SQL con=new Con_SQL();
			con.Con_SQL();
			PreparedStatement 	stmt=null;
			ResultSet rs=null;
				try {     String sql="update user set password = ? where id= ?";
						stmt = con.connect.prepareStatement(sql);
						stmt.setString(1, newpassword);
						stmt.setInt(2, id);
					int	result=stmt.executeUpdate();
					if(result>0) System.out.print("�޸ĳɹ�");else System.out.print("�޸�ʧ��");
//					if(rs!=null)rs.close();
//						if(rs!=null)stmt.close();
//							if(rs!=null)con.connect.close();
					
				}catch (SQLException e1) {
					// TODO �Զ����ɵ� catch ��
					e1.printStackTrace();
				}
				
				
				finally {
					try {
					if(rs!=null)rs.close();}
					catch(Exception e2) {
						e2.printStackTrace(); 
					}
					try {if(rs!=null)stmt.close();
						}
					catch(Exception e3) {
						e3.printStackTrace(); 
					}
					try {if(rs!=null)con.connect.close();
						}
					catch(Exception e4) {
						e4.printStackTrace(); 
					}
				}
			
				}	
        
        
        
}

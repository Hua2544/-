package lx;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class StudentRequestimplement implements StudentService {

	public  static boolean isInt(String value){  //һ����̬�������ж���������ǲ�������
	       try {
	        Integer.parseInt(value);
	        return true;
	        } catch (Exception e) {
	            return false;
	        } 
	   }
	@Override
	public TableDTO  retrieveStudentsByName(StudentRequest request) {
		// TODO Auto-generated method stub
		StringBuilder sql=new StringBuilder();
		sql.append("select * from student ");
		if (request.getSearchKey() != null && !"".equals(request.getSearchKey( ).trim())){sql.append("where (").append("  name like '%"+request.getSearchKey().trim()+"%')");
		}
		sql.append("order by id asc limit ").append(request.getStart()).append(" ,")
		.append( request.getPageSize());

//		System.out.print(sql.toString());//desc
	
		Connection connect=null;
		PreparedStatement ps=null;
		ResultSet resultset=null;
		TableDTO returnDTO =new TableDTO();
		try {
			connect=DBconn.DBcon();
			ps=connect.prepareStatement(sql.toString());
			resultset=ps.executeQuery();	
			returnDTO.setData(fillData(resultset));   
			
			sql.setLength(0);
			sql.append( "select count(*) from student ");
			if (request.getSearchKey() != null && !"".equals(request.getSearchKey( ).trim())) {sql.append(" where name like '%"+request.getSearchKey( ).trim()+"%'");
			}
			ps = connect. prepareStatement( sql.toString()) ;
			resultset =ps.executeQuery();
			while(resultset.next()) {
				int count=resultset.getInt(1);
				returnDTO.setTotalCount(count);//System.out.print(count);
				return returnDTO;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
				try {
					DBclose(resultset,ps,connect);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		return null;
	}
	public TableDTO  retrieveStudentsByID(StudentRequest request) {
		// TODO Auto-generated method stub
		StringBuilder sql=new StringBuilder();
		sql.append("select * from student ");
		if (request.getSearchKey() != null && !"".equals(request.getSearchKey( ).trim())){sql.append("where  id="+request.getSearchKey());sql.append(" ");
		}
		sql.append("order by id asc limit ").append(request.getStart()).append(" ,")
		.append( request.getPageSize());
//		System.out.print(sql.toString());
	
		Connection connect=null;
		PreparedStatement ps=null;
		ResultSet resultset=null;
		TableDTO returnDTO =new TableDTO();
		try {
			connect=DBconn.DBcon();
			ps=connect.prepareStatement(sql.toString());
			resultset=ps.executeQuery();	
			returnDTO.setData(fillData(resultset));   
			
			sql.setLength(0);
			sql.append( "select count(*) from student ");
			if (request.getSearchKey() != null && !"".equals(request.getSearchKey( ).trim())) {sql.append(" where name like '%"+request.getSearchKey( ).trim()+"%'");
			}
			ps = connect. prepareStatement( sql.toString()) ;
			resultset =ps.executeQuery();
			while(resultset.next()) {
				int count=resultset.getInt(1);
				returnDTO.setTotalCount(count);//System.out.print(count);
				return returnDTO;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
				try {
					DBclose(resultset,ps,connect);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		return null;
	}
	public TableDTO  deleteStudent(StudentRequest request) {
		// TODO Auto-generated method stub
		StringBuilder sql=new StringBuilder();
		StringBuilder sql1=new StringBuilder();
		sql.append("delete from student where (id= 0)");
		if (request.getSearchKey() != null && !"".equals(request.getSearchKey( ).trim())){sql.append("or (   id=");sql.append(request.getSearchKey().trim()+")");
		}
		sql1.append("select * from student ");
		

		System.out.print(sql.toString());
		Connection connect=null;
		PreparedStatement ps=null;
		PreparedStatement ps1=null;
		int resultset=0;
		ResultSet resultset1=null;
		TableDTO returnDTO =new TableDTO();
		try {
			connect=DBconn.DBcon();
			ps=connect.prepareStatement(sql.toString());
			resultset=ps.executeUpdate();
			System.out.print("ɾ���ɹ�:"+resultset);
			ps1=connect.prepareStatement(sql1.toString());
			resultset1=ps1.executeQuery();
			returnDTO.setData(fillData(resultset1));   
			return returnDTO;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
				try {
					DBclose(null,ps,connect);
					DBclose(resultset1,ps1,connect);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		return null;
	}
			

	public TableDTO  insertStudent(StudentRequest request) {
		// TODO Auto-generated method stub
		AdminDo adminDo=new AdminDo();
	
//		String name =getNameText().getText(); 
// 		String  iD= getiDText().getText();    
// 		String  sex= getsexText().getText();   
// 		if (iD == null || "".equals(iD.trim())|| sex == null || "".equals(sex.trim())||
// 				name== null || "".equals( name.trim( ))) {
// 			JOptionPane.showMessageDialog(addStudentview, "��Ϣ����");
// 			return  null;	}
		StringBuilder sqlinsert=new StringBuilder();
		StringBuilder sql1=new StringBuilder();
		
//		sqlinsert.append("insert  into  student values("+iD+","+name+","+sex+")");
		sql1.append("select * from student ");
		

		System.out.print(sqlinsert.toString());
		Connection connect=null;
		PreparedStatement ps=null;
		PreparedStatement ps1=null;
		int resultset=0;
		ResultSet resultset1=null;
		TableDTO returnDTO =new TableDTO();
		try {
			System.out.print("���ӽ���?");
			connect=DBconn.DBcon();
			ps=connect.prepareStatement(sqlinsert.toString());
			resultset=ps.executeUpdate();
			System.out.print("���ӳɹ�:"+resultset);
			ps1=connect.prepareStatement(sql1.toString());
			resultset1=ps1.executeQuery();
			returnDTO.setData(fillData(resultset1));   
			return returnDTO;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
				try {
					DBclose(null,ps,connect);
					DBclose(resultset1,ps1,connect);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		return null;
	}
	private void DBclose(ResultSet resultset, PreparedStatement ps, Connection connect) throws SQLException {
		// TODO Auto-generated method stub
		if(resultset!=null)resultset.close();else {System.out.print (" �����Ϊ��");}
		if(ps!=null)ps.close();else {System.out.print(" �������Ϊ��");}
		if(connect!=null) {connect.close();}else {System.out.print(" ����Ϊ��");}
	}

	private Vector<Vector<Object>> fillData(ResultSet resultset) throws SQLException {
		Vector<Vector<Object>> data=new Vector<>();
		while(resultset.next()) {
		Vector<Object> oneRecord=new Vector<>();
		int ID=resultset.getInt("id");
		String name=resultset.getString("name");
		String sex=resultset.getString("sex");
		oneRecord.add(ID);
		oneRecord.add(name);
		oneRecord.add(sex);
		data.add(oneRecord);
		
		
		}
		return data;
	}
	@Override
	public StudentDTO getById(int selectstudentid) {
		// TODO Auto-generated method stub
		StringBuilder sql = new StringBuilder("select * from student where id = ? ");
		StudentDTO studentDO = new StudentDTO();
		Connection connect=null;
		PreparedStatement ps=null;
		ResultSet resultSet=null;
		System.out.print(sql.toString());
		try {
			
			connect=DBconn.DBcon();
			ps=connect.prepareStatement(sql.toString());
			ps.setInt(1, selectstudentid);
			resultSet=ps.executeQuery();
			while(resultSet.next()) {
				int ID=resultSet.getInt("id");
				String name=resultSet.getString("name");
				String sex=resultSet.getString("sex");
				studentDO.setId(ID);
				studentDO.setName(name);
				studentDO.setSex(sex);
				
			}
			return studentDO;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
				try {
					DBclose(resultSet,ps,connect);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		return null;

	}
	@Override
	public boolean add(StudentDTO studentDo) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean updata(StudentDTO studentDo) {
		// TODO Auto-generated method stub
		StringBuilder sql = new StringBuilder();
		sql.append(" update student set name=? , sex=?");
		sql.append("where id=?");
		Connection connect=null;
		PreparedStatement ps=null;
		
		try {
			
			connect=DBconn.DBcon();
			ps=connect.prepareStatement(sql.toString());
			ps.setString(1, studentDo.getName());
			ps.setString(2, studentDo.getSex());
			ps.setInt(3, studentDo.getId());
			
		
			System.out.print(sql.toString());
			return ps.executeUpdate()==1;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
				try {
					DBclose(null,ps,connect);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		return false;
	}
	@Override
	public boolean deleteMutilp(int[] selectedstudentIds) {
		// TODO Auto-generated method stub
		StringBuilder sql = new StringBuilder();
		sql.append(" delete from student where id in ( ");
		int length = selectedstudentIds. length;
		for (int i = 0; i < length; i++) 
		{
				if (i == ( length - 1)) {
				sql.append(" ?");}
				else {
				sql.append(" ?, ");
				}
		}
		sql.append(")");
		Connection connect=null;
		PreparedStatement ps=null;
	try {
			
			connect=DBconn.DBcon();
			ps=connect.prepareStatement(sql.toString());
			for (int i = 0; i < length; i++) 
			{
				ps.setInt(i+1, selectedstudentIds[i]);
			}
			
		
			System.out.print(sql.toString());
			return ps.executeUpdate()==length;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
				try {
					DBclose(null,ps,connect);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
		
		return false;
	}
	
}

package lx;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

import javax.swing.*;

import java.io.*;


public   class Login extends JFrame {
	
	Login login;   //eeeee
	//��ǩ
//	JFrame jframe;	
	JPanel jpanel;
	JLabel titleName;
	JLabel userName;
	JLabel passWord;
	JButton comfirm;
	JButton reset;
//	JRadioButton jradiobutton;
//	JCheckBox jcheckbox;
	JTextField userNametext;
	JPasswordField passWordtext;
//	JTextArea jtextarea;
	JMenuBar menuBar=new JMenuBar();
	JMenu jMenu=new JMenu("asd");
	JMenuItem jLabel1=new  JMenuItem("saddsa?");
	JMenuItem jLabel2=new  JMenuItem("saddsa?");
	
	
	SystemTray  systemtray;
 	TrayIcon trayIcon;
 	Loginlisten loginlisten;//������������
	public void login() {
		// TODO Auto-generated constructor stub
		
		jMenu.add(jLabel1);
		jMenu.add(jLabel2);
		
		 loginlisten=new Loginlisten (this);  //���¼���������,��login������
		
		
//			jframe=new JFrame("С������Ϣ����ϵͳ");
		 //���õ��ɲ���
		 SpringLayout  springlayout=new SpringLayout();
		 jpanel=new  JPanel(springlayout);
			
			
//			Container contentpan=new Container();//  ����
			userName=new JLabel("�û���");
			passWord=new JLabel("����");
			titleName=new JLabel("С������Ϣ����ϵͳ");
			comfirm=new JButton("ȷ�ϵ�¼");
			reset=new JButton("����");
//			jradiobutton=new JRadioButton("ͨ������");
//			jcheckbox= new JCheckBox("��ѡ");
			userNametext=new JTextField("sadas",15);
			 passWordtext=new JPasswordField("sadsad",15);
//			 jtextarea =new JTextArea("�ı���",5,2);
			jMenu.add(jLabel1);
			jMenu.add(jLabel2);
			 menuBar.add(jMenu);
			 jpanel. add(menuBar);
			 jpanel.add(titleName);
			 jpanel.add(userName);
			 jpanel.add(passWord);
			 jpanel.add(comfirm);
			 comfirm.addActionListener(loginlisten);
			 jpanel.add(reset);
			 reset.addActionListener(loginlisten);
//			 jpanel.add(jradiobutton);
//			 jpanel.add(jtextarea);
			 jpanel.add(userNametext); 
			 jpanel.add(passWordtext); 
			 add(jpanel);
			 
			 
			 getRootPane().setDefaultButton(comfirm);
			 ImageIcon icon=new ImageIcon("xiaosongsu.png");
			//ImageIcon bg=new ImageIcon("xiaosongsu.png");
			  setIconImage(icon.getImage());
			 setSize(500,500);
			 JLabel bg=new JLabel(icon);
			 jpanel.add(bg);
			 //�������
//			 new Font("�����п�",Font.PLAIN,40);
			 titleName.setFont(new Font("�����п�",Font.PLAIN,40));
			
//			 jframe.setLocationRelativeTo(null);    //�Զ����з���һ
			 jpanel.setPreferredSize(new Dimension(250,250));
			 Dimension screenSize= Toolkit.getDefaultToolkit().getScreenSize();
			 int offsetX= (screenSize.width-500)/2 ; //System.out.println(offsetX);
			 int offsetY= (screenSize.height-500)/2 ; //System.out.println(offsetY);
			 setLocation(offsetX, offsetY);
			 
//			 jpanel.setVisible(true);//  ��ǰ�浼��Spring����
//			 jframe.setVisible(true);	 
			setTitle("С�������ϵͳ");
			 
			     
			
			 
//			Spring i= Spring.width(comfirm);System.out.print(i.getValue()); //getValue()��ȡ��ֵ
			  
			 
			 
			  //Ҫ��������ı߽���   ���   ����   �ο����   �ο��߽���  �ο����  �ȶ���SP
			 
			 springlayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, titleName, 10, SpringLayout.HORIZONTAL_CENTER,jpanel);
			 springlayout.putConstraint(SpringLayout.NORTH, titleName, 20, SpringLayout.NORTH,jpanel);
			 springlayout.putConstraint(SpringLayout.SOUTH, userName,150 , SpringLayout.NORTH,jpanel);
			 springlayout.putConstraint(SpringLayout.EAST, userName, 175, SpringLayout.WEST,jpanel);
			 springlayout.putConstraint(SpringLayout.NORTH, userNametext, 0, SpringLayout.NORTH,userName);
			 springlayout.putConstraint(SpringLayout.WEST, userNametext, 10, SpringLayout.EAST,userName);
			 springlayout.putConstraint(SpringLayout.NORTH, passWord, 10, SpringLayout.SOUTH,userName);
			 springlayout.putConstraint(SpringLayout.EAST, passWord, 0, SpringLayout.EAST,userName);
			 springlayout.putConstraint(SpringLayout.NORTH, passWordtext, 10, SpringLayout.SOUTH,userName);
			 springlayout.putConstraint(SpringLayout.WEST, passWordtext, 0, SpringLayout.WEST,userNametext);		 
			 springlayout.putConstraint(SpringLayout.NORTH, comfirm, 10, SpringLayout.SOUTH,passWord);
			 springlayout.putConstraint(SpringLayout.WEST, comfirm, 10, SpringLayout.EAST,passWord);
			 springlayout.putConstraint(SpringLayout.NORTH, reset, 0, SpringLayout.NORTH,comfirm);
			 springlayout.putConstraint(SpringLayout.WEST, reset, 10, SpringLayout.EAST,comfirm);
			 
			 if(SystemTray.isSupported()) {
				 systemtray= SystemTray.getSystemTray();
				  trayIcon= new TrayIcon(icon.getImage());
				 trayIcon.setImageAutoSize(true);
				 try {
					systemtray.add(trayIcon);
				 	} catch (AWTException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
				 							}
				this.addWindowListener(new WindowAdapter() {
					
					public void windowIconified(WindowEvent e) {
							if(login!=null) login.dispose(); 
					 }
					
				}   );
				trayIcon.addMouseListener(new MouseListener() {
					
				
					
					@Override
					public void mouseClicked(MouseEvent e) {
						// TODO Auto-generated method stub
						int clickcount=e.getClickCount();
						if(clickcount==1) {
							
							Login.this.setExtendedState(JFrame.NORMAL);
							
						}Login.this.setVisible(true);
					}

					@Override
					public void mousePressed(MouseEvent e) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void mouseReleased(MouseEvent e) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void mouseEntered(MouseEvent e) {
						// TODO Auto-generated method stub
						
					}

					@Override
					public void mouseExited(MouseEvent e) {
						// TODO Auto-generated method stub
						
					}
				});	

				 
			 }
			 
			
			
			 
			 
			 
			 
			 setResizable(false);
//			 jpanel.setBackground(Color.cyan);
			 jpanel. setVisible(true);
			 setVisible(true);
			 setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);    //һ��
//        	 jframe.setDefaultCloseOperation(jframe.DISPOSE_ON_CLOSE);
			 
			

			
			
			 
	}
     
			
			
	
	
	
	







	public static void main(String[] args) {
		
		Login login=new Login();
	
		login.login( );
		
		
	}
	
	
	
}

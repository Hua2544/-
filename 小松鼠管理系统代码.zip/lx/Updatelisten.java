package lx;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JOptionPane;

public class Updatelisten implements ActionListener{
	private  Updateview updateview;
	private  Mainview mainview;
	public Updatelisten(Updateview updateview,Mainview mainview) {
		// TODO Auto-generated constructor stub
		this.updateview=updateview;
		this.mainview=mainview;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		JButton jButton = (JButton) e.getSource();
		String text = jButton.getText();
		if("ȷ���޸�".equals(text)) 
		{
		StudentService studentservice = new StudentRequestimplement();
		StudentDTO studentDo = updateview.buildupdatastudentDo( ) ;
		boolean updataResult = studentservice.updata(studentDo) ;
				if(updataResult) {
					mainview.reloadTableByName();
					updateview.dispose();
				}else {
					JOptionPane.showMessageDialog(updateview, "�޸�ʧ��");
				}
		 
		}
	}

}

package lx;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;


public class Mainview extends JFrame {
		JPanel northPanel=new JPanel(new FlowLayout(FlowLayout.LEFT));
		JButton addBt=new JButton("����");
		JButton updateBt=new JButton("�޸�");
		JButton deleteBt=new JButton("ɾ��");
		JTextField searchTxt=new JTextField(15);		
		JButton searchBt=new JButton("����");
		JMenuBar menuBar=new JMenuBar();
		JMenu menu=new JMenu("����");
		JMenuItem searchByID=new JMenuItem("��ID����");
		JMenuItem searchByName=new JMenuItem("�����ֲ���");
		JPanel southPanel=new JPanel(new FlowLayout(FlowLayout.RIGHT));
		JButton preBt=new JButton("��һҳ");
		JButton nextBt=new JButton("��һҳ");
		
		MainviewTable mainviewTable=new MainviewTable(null);
		private int pageNow=1;
		private int pageSize=10;
		Mainlistener mainlistener;
		
		/**
		 * @return the pageSize
		 */
		public int getPageSize() {
			return pageSize;
		}

		/**
		 * @param pageSize the pageSize to set
		 */
		public void setPageSize(int pageSize) {
			this.pageSize = pageSize;
		}
		public void setPageNow(int pageNow) {
			this.pageNow=pageNow;
		}
		/**
		 * @return the pageNow
		 */
		public int getPageNow() {
			return pageNow;
		}

		public Mainview() {
		// TODO Auto-generated constructor stub	
		super( "������");
		Container container=getContentPane();
		mainlistener=new Mainlistener(this);
			
		northLayout(container);

		centerLayout(container);
	
		
		southLayout(container);
		
		
			ImageIcon icon=new ImageIcon("xiaosongsu.png");
			 setIconImage(icon.getImage());
			setSize(DimensionUtil.getBounds());
			setExtendedState(JFrame.MAXIMIZED_BOTH);
			setLocationRelativeTo(null);
			setResizable(true);
			setVisible(true);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);    //һ��
//    	 	jframe.setDefaultCloseOperation(jframe.DISPOSE_ON_CLOSE);
	
	
	}

	private void centerLayout(Container container) {
		Vector<Vector<Object>> data = getVectorByName();
		MainTableModel mainTableModel=MainTableModel.assembleModel(data);
		 mainviewTable.setDataModel(mainTableModel);
		 JScrollPane jscrollpane=new JScrollPane(mainviewTable);  //����ֱ�Ӽӵ�contentpane
		container.add(jscrollpane);
		mainviewTable.renderRule();
	}

	private void southLayout(Container container) {
		preBt.addActionListener(mainlistener);
		nextBt.addActionListener(mainlistener);
		southPanel.add(preBt);
		southPanel.add(nextBt);
		container.add(southPanel,BorderLayout.SOUTH);
	}


	private void northLayout(Container container) {
		
		addBt.addActionListener(mainlistener);
		updateBt.addActionListener(mainlistener);
		deleteBt.addActionListener(mainlistener);
		searchBt.addActionListener(mainlistener);
		SearchListen searchListen =new SearchListen(this);
		searchByID.addActionListener(searchListen);
		searchByName.addActionListener(searchListen);
		menu.add(searchByID);
		menu.add(searchByName);
		menuBar.add(menu);
		
		northPanel.add(addBt);
		northPanel.add(updateBt);
		northPanel.add(deleteBt);
//		northPanel.add(searchBt);
		northPanel.add(searchTxt);
		northPanel.add(menuBar);
		container.add(northPanel,BorderLayout.NORTH);
	}
	private void showPreNext( ) {
		if (this.pageNow == 1)
		{preBt.setVisible(false);}
		else{
		preBt.setVisible( true);
		}
	}
	public static void main(String[] args) {
		new Mainview();
	}

	public void reloadTableByName() {
		// TODO Auto-generated method stub
		Vector<Vector<Object>> data = getVectorByName();
		MainTableModel.updataModel(data);
		mainviewTable.renderRule();
	}
	public void reloadTableByID() {
		// TODO Auto-generated method stub
		Vector<Vector<Object>> data = getVectorByID();
		MainTableModel.updataModel(data);
		mainviewTable.renderRule();
	}
	public void reloadTabledelete() {
		// TODO Auto-generated method stub
		Vector<Vector<Object>> data = getVectorDelete();
		MainTableModel.updataModel(data);
		mainviewTable.renderRule();
	}
//	public void reloadTableinsert() {
//		// TODO Auto-generated method stub
//		Vector<Vector<Object>> data = getVectorDelete();
//		MainTableModel.updataModel(data);
//		mainviewTable.renderRule();
//	}
	private Vector<Vector<Object>> getVectorByName() {
		StudentService studentService=new StudentRequestimplement();
		StudentRequest request=new StudentRequest();
		request.setPageNow(pageNow);
		request.setPageSize(pageSize);
		request.setSearchKey(searchTxt.getText().trim()	);
		TableDTO tableDTO=studentService.retrieveStudentsByName(request);
		Vector<Vector<Object>>  data=tableDTO.getData();
		return data;
	}
	private Vector<Vector<Object>> getVectorByID() {
		StudentService studentService=new StudentRequestimplement();
		StudentRequest request=new StudentRequest();
		request.setPageNow(pageNow);
		request.setPageSize(pageSize);
		request.setSearchKey(searchTxt.getText().trim()	);
		TableDTO tableDTO=studentService.retrieveStudentsByID(request);
		Vector<Vector<Object>>  data=tableDTO.getData();
		return data;
	}
	private Vector<Vector<Object>> getVectorDelete() {
		StudentService studentService=new StudentRequestimplement();
		StudentRequest request=new StudentRequest();
		request.setPageNow(pageNow);
		request.setPageSize(pageSize);
		request.setSearchKey(searchTxt.getText().trim()	);
		TableDTO tableDTO=studentService.deleteStudent(request);
		Vector<Vector<Object>>  data=tableDTO.getData();
		return data;
	}

	public int[] getSelectediDs() {
		int[] selectedRows=mainviewTable.getSelectedRows();
		int[] ids=new int [selectedRows.length];
		for (int i = 0; i < selectedRows.length; i++) {
			int rowIndex=selectedRows[i];
			Object	idObj=	mainviewTable.getValueAt(rowIndex, 0);
			ids[i]=Integer.valueOf(idObj.toString());
			
		}
		return ids;
	}
	
	
}

 class DimensionUtil{
	 public static Dimension  getBounds() {
		Dimension screenSize=Toolkit.getDefaultToolkit().getScreenSize();
		 //��֤�����治�Ḳ���������������
		Insets screenInsets=Toolkit. getDefaultToolkit().getScreenInsets(new JFrame().getGraphicsConfiguration());
		new Rectangle(screenInsets.left,screenInsets.top,screenSize.width-screenInsets.left-screenInsets.right,screenSize.height-screenInsets.top-screenInsets.bottom
				);
	
		
		 return screenSize;
	}
 }
	
	  
  
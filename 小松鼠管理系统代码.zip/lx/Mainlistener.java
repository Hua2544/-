package lx;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Mainlistener implements ActionListener {
	private  Mainview mainview;
	
	public Mainlistener (Mainview mainview) {
		// TODO Auto-generated constructor stub
		this.mainview=mainview;
	}
	

//	@Override11
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	 	  JButton  jbutton=(JButton)e.getSource();
	 	  String text=jbutton.getText();
	 	  if("����".equals(text)) {
	 		  new AddStudentview(mainview);
	 		  
	 	  }else if("�޸�".equals(text)){
	 		 int[] selectedstudentIds = mainview.getSelectediDs();
	 		 if ( selectedstudentIds.length != 1) {
	 		JOptionPane.showMessageDialog(mainview, "һ��ֻ���޸�һ��!");
	 		 return;
	 		 }
	 	  new 	Updateview(mainview,selectedstudentIds[0]);

		
		}else if("ɾ��".equals(text)){
//			mainview.reloadTabledelete();  //��IDɾ������
			 int[] selectedstudentIds = mainview.getSelectediDs();
	 		if ( selectedstudentIds.length == 0) {
	 			JOptionPane.showMessageDialog(mainview,"��ѡ��Ҫɾ������!");
	 			return;
	 			}
	 		int option=	JOptionPane.showConfirmDialog(mainview, "��ȷ��Ҫɾ��ѡ���"+selectedstudentIds.length 
	 				+"����?","ȷ��ɾ��",JOptionPane.YES_NO_OPTION);
	 			if(option==JOptionPane.YES_OPTION) {
	 				StudentService studentService=new StudentRequestimplement();
	 			boolean deleteResult=studentService.deleteMutilp(selectedstudentIds);
				if(deleteResult) {
					mainview.reloadTableByName();
					
				}else {
					JOptionPane.showMessageDialog(mainview, "ɾ��ʧ��");
				}
	 			}
	 	  
			
		}else if("����".equals(text)){
			mainview.setPageNow(1);
			mainview.reloadTableByName();
		}else if("��һҳ".equals(text)){
			mainview.setPageNow(mainview.getPageNow()-1);
			mainview.reloadTableByName();
		}else if("��һҳ".equals(text)){
			mainview.setPageNow(mainview.getPageNow()+1);
			mainview.reloadTableByName();
		}
	}
}
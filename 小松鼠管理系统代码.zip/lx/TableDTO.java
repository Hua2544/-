package lx;

import java.util.Vector;

public class TableDTO {

	private Vector<Vector<Object>> data;
	private int totalCount;
	/**
	 * @return the data
	 */
	public Vector<Vector<Object>> getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(Vector<Vector<Object>> data) {
		this.data = data;
	}
	/**
	 * @return the totalCount
	 */
	public int getTotalCount() {
		return totalCount;
	}
	/**
	 * @param totalCount the totalCount to set
	 */
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	

}

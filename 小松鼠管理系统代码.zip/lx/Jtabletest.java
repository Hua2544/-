package lx;

import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;


public class Jtabletest extends JFrame {
	
	
	public Jtabletest() {
		// TODO Auto-generated constructor stub	
		super( "����JTable");
		
		
//		Vector< String> columns= new Vector<>();   //��
//		columns.addElement("���");
//		columns.addElement("����");
//		columns.addElement("�Ա�");
//		columns.addElement("����");
//		columns.addElement("����");
//		columns.addElement("�ֻ�");
//		columns.addElement("����");
		Vector<Vector<Object>> data= new Vector<>();
		Vector<Object> rowVector1=new Vector<>();
		rowVector1.add("2");
		rowVector1.add("����");
		rowVector1.add("��");
		rowVector1.add("11");
		rowVector1.add("����");
		rowVector1.add("1564");
		rowVector1.add("1654");
		Vector<Object> rowVector2=new Vector<>();
		rowVector2.add("2");
		rowVector2.add("����");
		rowVector2.add("��");
		rowVector2.add("11");
		rowVector2.add("����");
		rowVector2.add("1564");
		rowVector2.add("1654");
		Vector<Object> rowVector3=new Vector<>();
		rowVector3.add("2");
		rowVector3.add("����");
		rowVector3.add("��");
		rowVector3.add("11");
		rowVector3.add("����");
		rowVector3.add("1564");
		rowVector3.add("1654");
		data.addElement(rowVector1);
		data.addElement(rowVector2);
		data.addElement(rowVector3);
		
//		DefaultTableModel  defaulttablemodel=new DefaultTableModel();
//		defaulttablemodel.setDataVector(data, columns);
		
		StudentTableModel  studentTableModel=StudentTableModel.assembleModel(data); 
		JTable jtable= new JTable(studentTableModel);
		
		JTableHeader jtableheader=jtable.getTableHeader(); //��ȡjtable��ͷ
		jtableheader.setFont(new Font("΢���ź�", Font.BOLD, 16));
		jtableheader.setForeground(Color.RED);
//		jtable.getColumn(jtableheader);   //����
		
		
		//����
		jtable.setFont(new Font(null, Font.PLAIN, 14));
		jtable.setForeground(Color.black);
		jtable.setGridColor(Color.BLACK);
		jtable.setRowHeight(30);
		//ѡ�����
		jtable.getSelectionModel().setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
		//��������Ⱦ��ʽ
		
//		for (Iterator iterator = columns.iterator(); iterator.hasNext();) {
//			String string = (String) iterator.next();			
//		} 	
		Vector<String> columns = StudentTableModel.getColumns();
		StudentCellRender render =new StudentCellRender();
		for (int i = 0; i < columns.size(); i++) {
			TableColumn column=jtable.getColumn(columns.get(i));
			column.setCellRenderer(render);
			if(i==0) {
				column.setPreferredWidth(50);
				column.setMaxWidth(50);
				column.setResizable(false);
			}
		}
		
		
		 Container contentpane=getContentPane();
//			Container  jpanel= getContentPane();  //JPanel ����
		 JScrollPane jscrollpane=new JScrollPane(jtable);  //����ֱ�Ӽӵ�contentpane
		 contentpane.add(jscrollpane);
		 
		
		
		
		
		 
			setSize(600,400);
			setLocationRelativeTo(null);
			setResizable(false);
			setVisible(true);
			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);    //һ��
//    	 	jframe.setDefaultCloseOperation(jframe.DISPOSE_ON_CLOSE);
	
	
	}
		
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Jtabletest();
	}
	
	
}
 
	class  StudentCellRender  extends  DefaultTableCellRenderer{

//		@Override
//		public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus,
//				int row, int column) {
//			// TODO Auto-generated method stub
//			return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
//		}
		@Override
		 public Component getTableCellRendererComponent(JTable table, Object value,
                 boolean isSelected, boolean hasFocus, int row, int column) {
			  	if(row %2==0) {
			  		setBackground(Color.lightGray);
			  	}else {
			  		setBackground(Color.white);
			  	}
			  	setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
			 return super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
		 }
		
	
	}	 
   class StudentTableModel extends DefaultTableModel{
	  static Vector< String> columns= new Vector<>();
	  static
		{columns.addElement("���");
		columns.addElement("����");
		columns.addElement("�Ա�");
		columns.addElement("����");
		columns.addElement("����");
		columns.addElement("�ֻ�");
		columns.addElement("����");
	  }
	  
	  private StudentTableModel () {
		  super(null,columns);
	  }
	  
	  
	    



		public static Vector<String> getColumns() {
		// TODO Auto-generated method stub
			return columns;
	}






		private  static StudentTableModel studentTableModel=new StudentTableModel();
	  public static StudentTableModel  assembleModel(Vector<Vector<Object>>  data) {
		  studentTableModel.setDataVector(data, columns);	
		  return  studentTableModel;
	  }
	  @Override
	public boolean isCellEditable(int row, int column) {
		// TODO Auto-generated method stub
		return false;
	}
	  
  }
  
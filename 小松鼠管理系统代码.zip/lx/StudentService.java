package lx;

public interface StudentService {

	TableDTO retrieveStudentsByName(StudentRequest request);

	TableDTO deleteStudent(StudentRequest request);
	TableDTO insertStudent(StudentRequest request);

	StudentDTO getById(int selectstudentid);

	boolean add(StudentDTO studentDo);

	boolean updata(StudentDTO studentDo);

	boolean deleteMutilp(int[] selectedstudentIds);

	TableDTO retrieveStudentsByID(StudentRequest request);

}

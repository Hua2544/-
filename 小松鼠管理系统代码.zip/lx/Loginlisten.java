package lx;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Loginlisten implements ActionListener {    //����
	private  Login login;
	
	public  Loginlisten(Login login) {
		// TODO Auto-generated constructor stub
		this.login=login;
	}
	
	
	public JTextField  getpassWordText() {
		return login.passWordtext;        //���е�����
	}
	public JTextField  getUserNametext() {
		return login.userNametext;
	}
//	@Override11
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	 	  JButton  jbutton=(JButton)e.getSource();
	 	  String text=jbutton.getText();
	 	  if("ȷ�ϵ�¼".equals(text)) {
	 		String user =getUserNametext().getText(); 
	 		String  pwt= getpassWordText().getText();    //���ﲻһ��
	 		if (user == null || "".equals(user.trim())||
	 				pwt== null || "".equals( pwt.trim( ))) {
	 			JOptionPane.showMessageDialog(login, "�û����������");
	 			return;	}
	 		System.out.println(user+" : "+pwt);
	 		  
	 		  //��ѯdb
	 		
	 			new DBconn().DBcon(); 
	 			AdminDo adminDo=new AdminDo();
	 			adminDo.setUserName(user);
	 			adminDo.setPassWord(pwt);
	 			Boolean	flag=DBconn.loginCheck(adminDo);System.out.println("�Ҿ�����4");
	 		  if(flag) {
	 			  		new Mainview();
	 			  		login.dispose(); 
	 		  }else {
	 			 JOptionPane.showMessageDialog(login, "�û����������");
	 		  }
	 		  
	 		 System.out.println("ȷ�ϵ�¼");
	 	  }else if("����".equals(text)) {
	 		  getUserNametext().setText("");
	 		  getpassWordText().setText("");
	 		  System.out.println("����");
	 	  }
	}
		
		
		public void keyPressed(KeyEvent e) {
		if(KeyEvent.VK_ENTER==e.getKeyCode()) {
			String user =getUserNametext().getText(); 
	 		String  pwt= getpassWordText().getText();    //���ﲻһ��
	 		System.out.println(user+" : "+pwt);
	 		  Boolean flag=true;
	 		  //��ѯdb
	 		  if(flag) {
	 			 new Mainview();
			  		login.dispose(); 
	 		  }else {
	 			  JOptionPane.showMessageDialog(login, "�û����������");
	 		  }
	 		  
	 		 System.out.println("ȷ�ϵ�¼");
		}
			
		}

			public static void main(String[] args) {
		
			}
	
	
	
	

	

}

package lx;

public class StudentRequest {

	 private int pageNow;
	 private int pageSize;
	 private int start;
	 //��ѯ��
	 private String searchKey;

	/**
	 * @return the pageNow
	 */
	public int getStart() {
		return    (pageNow-1)*pageSize;
	}
	public int getPageNow() {
		return pageNow;
	}
	/**
	 * @param pageNow the pageNow to set
	 */
	public void setPageNow(int pageNow) {
		this.pageNow = pageNow;
	}
	/**
	 * @return the pageSize
	 */
	public int getPageSize() {
		return pageSize;
	}
	/**
	 * @param pageSize the pageSize to set
	 */
	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
	/**
	 * @return the searchKey
	 */
	public String getSearchKey() {
		return searchKey;
	}
	/**
	 * @param searchKey the searchKey to set
	 */
	public void setSearchKey(String searchKey) {
		this.searchKey = searchKey;
	}
	

}

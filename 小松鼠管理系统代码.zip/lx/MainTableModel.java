package lx;

import java.util.Vector;

import javax.swing.table.DefaultTableModel;

public class MainTableModel    extends    DefaultTableModel{
	  static Vector< String> columns= new Vector<>();
	  static
		{	columns.addElement("ID");
			columns.addElement("����");
			columns.addElement("�Ա�");
	  }
	  
	  public MainTableModel() {
		  super(null,columns);
	  }

		public static Vector<String> getColumns() {
		// TODO Auto-generated method stub
			return columns;
	}






		public static MainTableModel mainTableModel=new MainTableModel ();//��ʼ��
		//��columns װ�� data
	  public static MainTableModel  assembleModel(Vector<Vector<Object>>  data) {
		  mainTableModel.setDataVector(data, columns);	
		  return  mainTableModel;
	  }
	  //һ��
	  public static MainTableModel  updataModel(Vector<Vector<Object>>  data) {
		  mainTableModel.setDataVector(data, columns);	
		  return  mainTableModel;
	  }
	  
	  @Override
	public boolean isCellEditable(int row, int column) {
		// TODO Auto-generated method stub
		return false;
	}
	  
}
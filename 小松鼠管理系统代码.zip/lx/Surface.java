package lx;


import java.awt.BorderLayout;
import java.awt.Desktop.Action;
import java.awt.MenuBar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButton;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JTextArea;
import javax.swing.JTextField;

   public class Surface{
	   JFrame f= new JFrame("�������");
	 
	   
	   //��������齨
	   JMenuBar menubar=new JMenuBar();
	   
	    JMenu filemenu=new JMenu("�ļ�");
	    JMenu editmenu=new JMenu("�༭");
	    
	    
	    JMenuItem auto=new JMenu("�Զ�����");
	    JMenuItem copy=new JMenu("����");
	    JMenuItem paste=new JMenu("ճ��");
	    
	    JMenu formatmenu=new JMenu("��ʽ");
	    
	    JMenuItem comment=new JMenu("ע��");
	    JMenuItem cancelcomment=new JMenu("ȡ��ע��");
	   //�ı���
	    JTextArea jta=new JTextArea(8,8);
	    //�б���
	    String[] colors={"��ɫ","��ɫ","��ɫ"};
	   JList<String> colorlist=new JList<String>(colors);
	   //����ѡ������齨
	   JComboBox<String>  colorSelect=new JComboBox<String>();
	   
	   ButtonGroup bg= new ButtonGroup();
	   JRadioButton male=new JRadioButton("��",false);
	   JRadioButton female=new JRadioButton("Ů",true);
	   //
	   JCheckBox ismarried= new JCheckBox("�Ƿ��ѻ�");
	   //�����ײ�
	   JTextField  jtf=new JTextField(40);
	   JButton ok=new JButton();
	   //�����Ҽ��˵�
	   
	   JPopupMenu jpm=new JPopupMenu();
	   
	   ButtonGroup bg1=new ButtonGroup();
	   
	   
	   JRadioButtonMenuItem jrbm=new JRadioButtonMenuItem("Metal ���");
	   JRadioButtonMenuItem jrbm1=new JRadioButtonMenuItem("Nimbus ���");
	   JRadioButtonMenuItem jrbm2=new JRadioButtonMenuItem("WIndows ���");
	   JRadioButtonMenuItem jrbm3=new JRadioButtonMenuItem("Windows ���� ���");
	   JRadioButtonMenuItem jrbm4=new JRadioButtonMenuItem("Metal ������"); 
	   
	   //��ʼ�� ��װ
	   public void init() {
		   //
		   
		   
		   
		   //��װ�ײ�
		   JPanel bottombuttonjp=new JPanel();
		   
		   bottombuttonjp.add(jtf);
		   bottombuttonjp.add(ok);
		   
		   f.add(bottombuttonjp,BorderLayout.SOUTH);
		   
		   //��װѡ������齨
		   
		   JPanel selectjp=new JPanel();
		   
		   colorSelect.addItem("��");
		   colorSelect.addItem("��");
		   colorSelect.addItem("��");
		   
		   bg.add(male);
		   bg.add(female);
		   selectjp.add(male);
		   selectjp.add(female);
		   selectjp.add(ismarried);
		   selectjp.add(colorSelect);
		   
		   //��װ�ı����ѡ���ȹ��齨
		   Box topLeft=Box.createVerticalBox();
		   topLeft.add(jtf);
		   topLeft.add(selectjp);
		   
		   //��װ����
		    Box top=Box.createHorizontalBox();
		    top.add(topLeft,colorlist);
		    
		    f.add(top);
		   //��װ�����˵�
		    
		    formatmenu.add(comment);
		    formatmenu.add(cancelcomment);
		    
		    editmenu.add(auto);
		    editmenu.addSeparator();
		    editmenu.add(copy);
		    editmenu.add(paste);
		    editmenu.addSeparator();
		    editmenu.add(formatmenu);
		    
		    menubar.add(filemenu);
		    menubar.add(editmenu);
		    f.setJMenuBar(menubar);
		    	//�Ҽ��˵�
		   jpm.add(jrbm);
		   jpm.add(jrbm1);
		   jpm.add(jrbm2);
		   jpm.add(jrbm3);
		   jpm.add(jrbm3);
		   
		   ActionListener listener=new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO �Զ����ɵķ������
				
			}
		};
		f.pack();
		  f.setVisible(true); 
		  
		    
	   }
	   
	   
	   
	   
	   
	
	    
	   
	   
	 
	   
	   
	  public static void main(String[] args) {
		  
	  new Surface().init();  
	  
		  
		  
		  
		  
		  
		  
		  
		  									/*	Frame frame= new Frame(" ���Ǳ���");
												
											 Panel panel=new Panel(); frame.add(panel) ;
												 panel.setBounds(10, 10,100, 100);
											 panel.add(new TextArea(" �������"));
											 panel.add(new Button("������� "));
												
											 
												 frame.setLocation(100,100);
												frame.setSize(500,500); 
												frame.setVisible(true); */
	}
	   
   }
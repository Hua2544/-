package lx;

public class Deletemethod {
	public Deletemethod() {

	}

}

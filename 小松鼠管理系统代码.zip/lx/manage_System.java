package lx;

public class manage_System {
	public static void main(String[] args) {
		

		
		
		
		
		
		
		
		
		
		
	System_Method.selectAll();
//    	System_Method.selectByusername("liu");
//		System_Method.selectByid(1);
//		System.out.print(System_Method.selectBypage(1,1));	
//		System_Method.insert("����","123");	
//		System_Method. deleteByid(4);      
//		System_Method.updatePassword(6,"123456");			
				
				
				
				
				
		
				
				
				
				

	}
	
}

package lx;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
			
public class AddStudentlistener implements ActionListener {
	private  AddStudentview  addStudentview;
			
	public AddStudentlistener (AddStudentview addStudentview,Mainview mainview) {
		// TODO Auto-generated constructor stub
		this.addStudentview=addStudentview;
	}
	


		public JTextField  getID() {
		return addStudentview.iDField;        //���е�����
		}
		public JTextField  getSEX() {
		return addStudentview.sexField;}
		public JTextField  getNAME() {
		return addStudentview.nameField;}

	//	@Override11
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	 	  JButton  jbutton=(JButton)e.getSource();
	 	  String text=jbutton.getText();
	 	  if("ȷ��".equals(text)) {
	 		String iD=getID().getText();
	 		String name=getNAME().getText();
	 		String sex=getSEX().getText();
			AdminDo adminDo=new AdminDo();
			

	 		if (iD == null || "".equals(iD.trim())|| sex == null || "".equals(sex.trim())||
	 				name== null || "".equals( name.trim( ))) {
	 			JOptionPane.showMessageDialog(addStudentview, "��Ϣ����");
 			return  ;	}
			StringBuilder sqlinsert=new StringBuilder();
			StringBuilder sql1=new StringBuilder();
			
			sqlinsert.append("insert  into  student values("+iD+",'"+name+"','"+sex+"')");
			
			

			System.out.print(sqlinsert.toString());
			Connection connect=null;
			PreparedStatement ps=null;
			int resultset=0;
			ResultSet resultset1=null;
			TableDTO returnDTO =new TableDTO();
			try {
				
				connect=DBconn.DBcon();
				ps=connect.prepareStatement(sqlinsert.toString());
				resultset=ps.executeUpdate();
				if(resultset!=0)JOptionPane.showMessageDialog(addStudentview, "���ӳɹ�");
				System.out.print("���ӳɹ�:"+resultset);
//				ps1=connect.prepareStatement(sql1.toString());
//				resultset1=ps1.executeQuery();
//				Vector<Vector<Object>> data=new Vector<>();
//				while(resultset1.next()) {
//				Vector<Object> oneRecord=new Vector<>();
//				int ID=resultset1.getInt("id");
//				String Name=resultset1.getString("name");
//				String Sex=resultset1.getString("sex");
//				oneRecord.add(ID);
//				oneRecord.add(name);
//				oneRecord.add(sex);
//				data.add(oneRecord);

			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			finally {
					try {
						if(resultset1!=null)resultset1.close();else {System.out.print (" �����Ϊ��");}
						if(ps!=null)ps.close();else {System.out.print(" �������Ϊ��");}
						if(connect!=null) {connect.close();}else {System.out.print(" ����Ϊ��");}
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					
	 		  
	 		  
	 		  
//	 	 addStudentview.reloadTableinsert();
	 	 System.out.print(iD);
	 	 System.out.print(name);
	 	 System.out.print(sex);}
		 addStudentview.dispose();
		 
	 	  }
			}else if("����".equals(text)){
	 		 getiDText().setText("");
	 		  getNameText().setText("");
	 		  getsexText().setText("");
	 		  System.out.println("����");
		}
	}


private JTextField getsexText() {
		// TODO Auto-generated method stub
		return addStudentview.sexField;
	}


private JTextField getNameText() {
		// TODO Auto-generated method stub
		return addStudentview.nameField;
	}


private JTextField getiDText() {
	// TODO Auto-generated method stub
	return addStudentview.iDField;
}
}
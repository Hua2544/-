package lx;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.util.Iterator;
import java.util.Vector;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;






public class Updateview extends JDialog {
     	JLabel iD=new JLabel("ID");
		JLabel name=new JLabel("Name");
  		JLabel sex=new JLabel("sex");
static  JTextField iDField=new JTextField(15);
static	JTextField nameField=new JTextField(15);
		JTextField sexField=new JTextField(15);
		JButton comfirm=new JButton("ȷ���޸�");
		JButton reset=new JButton("����");
		JPanel jPanel;
		
		MainviewTable mainviewTable=new MainviewTable(null);
		Updatelisten updatelisten;
		public Updateview(Mainview mainview, int selectedstudentIds) {
		// TODO Auto-generated constructor stub	
		super(mainview, "�޸�ѧ����Ϣ",true);
		//��ѯѡ��id��Ӧ��¼����;
		StudentService studentService=new StudentRequestimplement();
		StudentDTO selectStudent=studentService.getById(selectedstudentIds);
		Container container=getContentPane();
		updatelisten=new Updatelisten(this, mainview);
		
		SpringLayout  springlayout=new SpringLayout();
		jPanel=new  JPanel(springlayout);
		comfirm.addActionListener(updatelisten);
		reset.addActionListener(updatelisten);
		jPanel.add(iD);
		iDField.setText(selectStudent.getId()+"");
		iDField.setEnabled(false);
		jPanel.add(iDField);
		jPanel.add(name);
		nameField.setText(selectStudent.getName());
		jPanel.add(nameField);
		jPanel.add(sex);
		sexField.setText(selectStudent.getSex());
		jPanel.add(sexField);
		
		
		
		
		jPanel.add(comfirm);
		jPanel.add(reset);
		
		
		 springlayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, iD, -80, SpringLayout.HORIZONTAL_CENTER,jPanel);
		 springlayout.putConstraint(SpringLayout.NORTH, iD, 20, SpringLayout.NORTH,jPanel);
		 
		 springlayout.putConstraint(SpringLayout.WEST, iDField, 10, SpringLayout.EAST,iD);
		 springlayout.putConstraint(SpringLayout.NORTH, iDField, 0, SpringLayout.NORTH,iD);
		 
		 springlayout.putConstraint(SpringLayout.EAST,name, 0, SpringLayout.EAST,iD);
		 springlayout.putConstraint(SpringLayout.NORTH, name, 30, SpringLayout.NORTH,iD);
		 springlayout.putConstraint(SpringLayout.WEST, nameField, 10, SpringLayout.EAST,iD);
		 springlayout.putConstraint(SpringLayout.NORTH, nameField, 30, SpringLayout.NORTH,iD);
		 
		 springlayout.putConstraint(SpringLayout.EAST,sex, 0, SpringLayout.EAST,iD);
		 springlayout.putConstraint(SpringLayout.NORTH, sex, 60, SpringLayout.NORTH,iD);
		 springlayout.putConstraint(SpringLayout.WEST, sexField, 10, SpringLayout.EAST,iD);
		 springlayout.putConstraint(SpringLayout.NORTH, sexField, 60, SpringLayout.NORTH,iD);
		 
		 springlayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, comfirm, -40, SpringLayout.HORIZONTAL_CENTER,jPanel);
		 springlayout.putConstraint(SpringLayout.SOUTH, comfirm, -20, SpringLayout.SOUTH,jPanel);
		 springlayout.putConstraint(SpringLayout.HORIZONTAL_CENTER, reset, 40, SpringLayout.HORIZONTAL_CENTER,jPanel);
		 springlayout.putConstraint(SpringLayout.SOUTH, reset, -20, SpringLayout.SOUTH,jPanel);
		 container.add(jPanel,BorderLayout.CENTER);
	
		
		
	
		
		
		
		
			ImageIcon icon=new ImageIcon("xiaosongsu.png");
			 setIconImage(icon.getImage());
			setSize(300,200);
			setLocationRelativeTo(null);
			setResizable(false);
			setVisible(true);
//			setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);    //һ��
    	 	setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
	
	
	}

	
	/**
	 * @return the iDField
	 */
	public JTextField getiDField() {
		return iDField;
	}

	/**
	 * @return the nameField
	 */
	public JTextField getNameField() {
		return nameField;
	}

	/**
	 * @return the sexField
	 */
	public JTextField getSexField() {
		return sexField;
	}

	public void reloadTableinsert() {
		// TODO Auto-generated method stub
		Vector<Vector<Object>> data = getVectorDelete();
		MainTableModel.updataModel(data);
		mainviewTable.renderRule();
	}
	private Vector<Vector<Object>> getVectorDelete() {
		StudentService studentService=new StudentRequestimplement();
		StudentRequest request=new StudentRequest();
		
		
		
		TableDTO tableDTO=studentService.insertStudent(request);
		Vector<Vector<Object>>  data=tableDTO.getData();
		return data;
	}
//	public StudentDTO builtStudent() {
//		
//		StudentDTO studentDTO =new StudentDTO();
//		studentDTO.setId(Integer.valueOf(iDField.getText()));
//		studentDTO.setName(nameField.getText());
//		studentDTO.setSex(sexField.getText());
//	
//
//		return studentDTO;
//	}
	
	
	
	public static void main(String[] args) {
//		new Updateview(null);
	}


	public StudentDTO buildupdatastudentDo() {
		// TODO Auto-generated method stub
		StudentDTO studentDTO =new StudentDTO();
		studentDTO.setId(Integer.valueOf(iDField.getText()));
		studentDTO.setName(nameField.getText());
		studentDTO.setSex(sexField.getText());
	

		return studentDTO;
	}
	
}

	
	  
  
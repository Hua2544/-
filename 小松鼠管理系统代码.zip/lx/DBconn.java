package lx;
import java.sql.*;
public class DBconn {
  static	String user;
  static 	String URL;
  static 	String userp;
  static	String driver; 
  static	Connection con=null;
  static	PreparedStatement preState=null;
  static	ResultSet rs=null;
	public static Connection DBcon() {
		// TODO Auto-generated constructor stub
	 URL="jdbc:mysql://localhost:3306/user?useSSL=false&Unicode=true&characterEncoding=UTF-8";
	 user="root";	
	 userp="admin";
	 driver="com.mysql.jdbc.Driver";
	 try {  
			Class.forName(driver);  //����MYSQL JDBC��������       
		//Class.forName("org.gjt.mm.mysql.Driver");     
		System.out.println("Success loading Mysql Driver!"); }  
		catch (Exception e) {     
			
			System.out.print("Error loading Mysql Driver!"+"\n");    
			e.printStackTrace();    }  
		try {    
		con = DriverManager.getConnection( URL,user,userp);  //����URLΪ  //use�ǰ汾���� jdbc:mysql//��������ַ/���ݿ���  �������2�������ֱ��ǵ�½�û���������    
		  System.out.println("Success connect Mysql server!");     
			}catch (Exception e1) {
				System.out.print("Error connecting Mysql !"+"\n");    
				e1.printStackTrace();  }
		System.out.println("����û����");
		return con;
	}
	
	public static Boolean loginCheck(AdminDo adminDo){
		String userName = adminDo.getUserName();
		String pwdParam = adminDo.getPassWord();
		if (userName == null || "".equals(userName.trim())) {
			System.out.println("�Ҿ�����6");
			return false;
		}
		if(con==null) {
			System.out.println("�Ҿ�����7");	return false;
		}else {
			String sql="select * from admin where userName='admin' ";
			try {
				System.out.println("�Ҿ�����7");
				preState= con.prepareStatement(sql);
				rs=preState.executeQuery();
				while(rs.next()) {
					String pwd=rs.getString(2);System.out.println("pwd");
					if(adminDo.getPassWord().equals(pwd)) {
						return true;
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
				try {
					DBclose(rs,preState,con);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			return false;
		}
	
	}
	


	public static void DBclose(ResultSet rs,PreparedStatement preState,Connection con) throws SQLException {

		if(rs!=null)rs.close();else {System.out.print (" �����Ϊ��");}
		if(preState!=null)preState.close();else {System.out.print(" �������Ϊ��");}
		if(con!=null) {con.close();}else {System.out.print(" ����Ϊ��");}
	}
	
	public static void main(String[] args) {
		
	}
}

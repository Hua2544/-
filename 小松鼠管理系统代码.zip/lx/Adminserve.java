package lx;

public interface Adminserve {
 
	boolean validdateAdmin(AdminDo adminDo);

}

package lx;

import java.awt.BorderLayout;

import javax.swing.*;

public class springlayouttest {

	
public springlayouttest() {
		// TODO Auto-generated constructor stub
		SpringLayout springlayout =new SpringLayout();
		JPanel jpanel =new JPanel(springlayout);
		JFrame jframe =new JFrame();
		JLabel	userName=new JLabel("�û���");
//		JButton	jbutton=new JButton("��¼");
//		JRadioButton	jradiobutton=new JRadioButton("ͨ������");
		
//		jpanel.add(jbutton);
//		jpanel.add(jradiobutton);
		jpanel.add(userName);
		jframe.add(jpanel);
		springlayout.putConstraint(SpringLayout.EAST, userName, -200 , SpringLayout.EAST, jpanel);
		springlayout.putConstraint(SpringLayout.NORTH, userName, -200 , SpringLayout.SOUTH, jpanel);
	
		jpanel.setSize(500,500);
		jframe.setSize(500,500);//JFrame ���ɼ�,JPanel�ɼ�
//		jpanel.setVisible(true); 
		jframe.setVisible(true); 
		
		
		
	}
	public static void main(String[] args) {
		springlayouttest sp=new springlayouttest();
		
	}
}

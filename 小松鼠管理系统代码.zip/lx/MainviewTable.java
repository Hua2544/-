package lx;

import java.awt.Color;
import java.awt.Font;
import java.util.Vector;

import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;

public class MainviewTable extends JTable {
		
	public void setDataModel(MainTableModel mainTableModel) {
			   this.setModel(mainTableModel);
		}
	public MainviewTable(MainTableModel mainTableModel) {
		
			super(mainTableModel);
			JTableHeader jtableheader=getTableHeader(); //��ȡjtable��ͷ
			jtableheader.setFont(new Font("΢���ź�", Font.BOLD, 16));
			jtableheader.setForeground(Color.RED);

			
			//����
			setFont(new Font(null, Font.PLAIN, 14));
			setForeground(Color.black);
			setGridColor(Color.BLACK);
			setRowHeight(30);
			//ѡ�����
			getSelectionModel().setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
			//��������Ⱦ��ʽ
		
		
	}
	
	
	public void renderRule() {
		Vector<String> columns = MainTableModel.getColumns();
		MainTabelRender render =new MainTabelRender();
		for (int i = 0; i < columns.size(); i++) {
			TableColumn column=getColumn(columns.get(i));
			column.setCellRenderer(render);
			if(i==0) {
				column.setPreferredWidth(50);
				column.setMaxWidth(50);
				column.setResizable(false);
			}
		}
	}

}

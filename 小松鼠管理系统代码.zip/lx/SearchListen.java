package lx;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

public class SearchListen implements ActionListener {
	private  Mainview mainview;
	public SearchListen(Mainview mainview) {
		// TODO Auto-generated constructor stub
		this.mainview=mainview;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		e.getActionCommand();
//		System.out.print(e.getActionCommand().toString());
		 if("��ID����".equals(e.getActionCommand())) {	
			 mainview.reloadTableByID();
	 	  }else if("�����ֲ���".equals(e.getActionCommand())){
	 		 mainview.reloadTableByName();
		}
	}

}
